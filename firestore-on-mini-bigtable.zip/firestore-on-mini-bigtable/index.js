const FirestoreOnMiniBigtable = require("./lib/firestore");
module.exports = FirestoreOnMiniBigtable;
