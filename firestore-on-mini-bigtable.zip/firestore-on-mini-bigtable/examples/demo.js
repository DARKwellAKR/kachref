const FirestoreOnMiniBigtable = require("..");

(async () => {
  const db = new FirestoreOnMiniBigtable("./data");
  await db.init();

  const users = db.collection("users");
  const userRef = users.doc("u1");

  await userRef.set({ name: "Achref", age: 20 });
  const fetched = await userRef.get();
  console.log("Fetched:", fetched);

  await db.close();
})();
